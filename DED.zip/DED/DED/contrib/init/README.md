Sample configuration files for:
```
systemd: bitcoind.service
Upstart: bitcoind.conf
OpenRC:  bitcoind.openrc
         bitcoind.openrcconf
CentOS:  bitcoind.init
macOS:   org.bitcoin.bitcoind.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
