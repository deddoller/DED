Updated settings
----------------

- Passing an invalid `-debug`, `-debugexclude`, or `-loglevel` logging configuration
  option now raises an error, rather than logging an easily missed warning. (#27632)
